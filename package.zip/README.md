# 脉络镜 Network Lens

把思源笔记里的文档级引用关系整理成可操作的分析面板，帮助你更快发现孤立文档、桥接节点、主题社区、传播路径和整理入口。

![脉络镜预览](https://raw.githubusercontent.com/famotime/siyuan-reference-analytics/main/preview.png)

## 适合解决什么问题

- 关系图太乱，只能看到“有连接”，却不知道先整理哪里。
- 笔记越积越多，想快速找出孤立文档、沉没文档和高传播价值节点。
- 需要基于真实引用证据做整理，而不是盯着大图手动猜。

## 当前能力

- 文档级引用热度排行
- 主题社区发现
- 孤立文档、沉没文档、桥接节点识别
- 时间趋势分析
- 传播路径与高传播价值节点
- 原始引用证据查看
- 可操作建议
- 顶部统计卡片点击联动详情
- 已读 / 未读文档识别与详情查看

## 平台支持与风险说明

- 当前已完成桌面端验证。
- 移动端与浏览器端暂未完成系统测试。
- “主题修复建议”会直接写回文档内容，建议先在测试库验证再用于正式笔记库。

## 截图

![分析面板](https://raw.githubusercontent.com/famotime/siyuan-reference-analytics/main/assets/image-20260321143603-yyqht4u.quickedit-convert-webp-1774075160113-20260321143920-ed2ln0p.webp)

![详情视图](https://raw.githubusercontent.com/famotime/siyuan-reference-analytics/main/assets/image-20260321143824-1lckav4.quickedit-convert-webp-1774075160589-20260321143920-v297w9q.webp)

## 安装与构建

```bash
npm install --legacy-peer-deps
npm test
npm run build
```

`npm run build` 会更新根目录 `package.zip`。
